package commands;

import java.awt.Color;

import breakout.Brick;
import javafx.geometry.Point2D;

public class BrickBreak implements Command{
	
	double previousX;
	double previousY;
	Brick b;
	
	public BrickBreak(Brick b) {
		Point2D point = b.getPosition();
		previousX = point.getX();
		previousY = point.getY();
		this.b = b;
	}

	@Override
	public void unexecute() {
		b.setPosition(point);
		b.setColor(Color.RED);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void execute(double timeDelta) {
		// TODO Auto-generated method stub
		b.update(timeDelta);
	}

}
