package observer.pattern;

public interface Observer {
	public void update(double timeDelta);
}
